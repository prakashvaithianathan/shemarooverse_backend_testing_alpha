/* eslint-disable prettier/prettier */
const { handleError } = require('../../middleware/utils')
const { getItems, checkQueryString } = require('../../middleware/db')
const axios = require('axios')
const Vimeo = require('@vimeo/vimeo').Vimeo
const http = require('https')
const crypto = require('crypto')

/**
 * Get items function called by route
 * @param {Object} req - request object
 * @param {Object} res - response object
 */

const client = new Vimeo(
  'c16cdbce1a6e9f68d3a6305395687fc2d7f7d3d9',
  'KcPCDl2y0q0a6VHrROP4uOGe5dh5ZcQViW0neWTgbIeAAMlfNBCmFZ2Kp/CwVdJy3AKt6M98Wyls5loMqranAGBcTmNaK2P2wQRPM7eyKfdERDV0GfeNwPPiW6KUdPNc',
  '88fc5fbd621988884e9c7eee9dd80931'
)

const getAllCategory = async (req, res) => {
  try {
    client.request(
      {
        path: '/categories',
        method: 'GET'
      },
      function (error, body, statusCode, headers) {
        if (error) {
          console.log('Error:', error)
          res.status(200).json(error)
        } else {
          console.log('Body:', body)
          res.status(200).json(body)
        }
      }
    )

    // const query = await checkQueryString(req.query)
    // res.status(200).json(await getItems(req, User, query))
  } catch (error) {
    handleError(res, error)
  }
}

const getAllMoviesFromCategory = async (req, res) => {
  try {
    client.request(
      {
        path: `/categories/${req.body.category}/videos`,
        method: 'GET'
      },
      function (error, body, statusCode, headers) {
        if (error) {
          console.log('Error:', error)
          res.status(200).json(error)
        } else {
          console.log('Body:', body)
          res.status(200).json(body)
        }
      }
    )

    // const query = await checkQueryString(req.query)
    // res.status(200).json(await getItems(req, User, query))
  } catch (error) {
    handleError(res, error)
  }
}

const getShemarooCatalog = async (req, res) => {
  try {
    const location = 'IN'
    const options = {
      hostname: process.env.SHEMAROO_BASEURL,
      path: `/catalog_lists/sample-catalogs?auth_token=${process.env.SHEMAROO_AUTH_TOKEN}&region=${location}`,
      method: 'GET'
    }

    const request = http.request(options, (response) => {
      let data = ''
      response.on('data', (chunk) => {
        data += chunk
      })

      response.on('end', () => {
        const parsedData = JSON.parse(data)
        res.status(200).json({
          success: true,
          result: parsedData,
          message: 'FETCHED_SUCCESSFULLY'
        })
      })
    })

    request.on('error', (error) => {
      res.status(400).json({
        success: false,
        result: error,
        message: 'URL_NOT_FOUND'
      })
    })

    request.end()
  } catch (error) {
    handleError(res, error)
  }
}

const getShemarooItems = async (req, res) => {
  try {
    const location = 'IN'
    const options = {
      hostname: process.env.SHEMAROO_BASEURL,
      path: `/catalogs/${req.body.friendly_id}/items?auth_token=${process.env.SHEMAROO_AUTH_TOKEN}&region=${location}`,
      method: 'GET'
    }

    const request = http.request(options, (response) => {
      let data = ''
      response.on('data', (chunk) => {
        data += chunk
      })

      response.on('end', () => {
        const parsedData = JSON.parse(data)
        res.status(200).json({
          success: true,
          result: parsedData,
          message: 'FETCHED_SUCCESSFULLY'
        })
      })
    })

    request.on('error', (error) => {
      res.status(400).json({
        success: false,
        result: error,
        message: 'CATALOGUE_NOT_FOUND'
      })
    })

    request.end()
  } catch (error) {
    handleError(res, error)
  }
}

const getShemarooEpisodes = async (req, res) => {
  try {
    const location = 'IN'
    const options = {
      hostname: process.env.SHEMAROO_BASEURL,
      path: `/catalogs/${req.body.friendly_id}/items/${req.body.episode_id}/episodes?auth_token=${process.env.SHEMAROO_AUTH_TOKEN}&region=${location}`,
      method: 'GET'
    }

    const request = http.request(options, (response) => {
      let data = ''
      response.on('data', (chunk) => {
        data += chunk
      })

      response.on('end', () => {
        const parsedData = JSON.parse(data)
        res.status(200).json({
          success: true,
          result: parsedData,
          message: 'FETCHED_SUCCESSFULLY'
        })
      })
    })

    request.on('error', (error) => {
      res.status(400).json({
        success: false,
        result: error,
        message: 'CATALOGUE_NOT_FOUND'
      })
    })

    request.end()
  } catch (error) {
    handleError(res, error)
  }
}

const getVideoStream = async (req, res) => {
  try {
    const smarturl_accesskey = process.env.SHEMAROO_SMARTURL_ACCESSKEY
    const smarturl_parameters = 'service_id=10&play_url=yes&protocol=hls&us='

    const md5Hash = crypto.createHash('md5')
    md5Hash.update(
      smarturl_accesskey + req.body.smart_url + '?' + smarturl_parameters,
      'utf8'
    )

    // Calculate the hex digest (output) from the hash object
    const md5HexDigest = md5Hash.digest('hex')

    const location = 'IN'

    const domain = req.body.smart_url.split('://')[1].split('/')[0]
    const path =
      '/' + req.body.smart_url.split('://')[1].split('/').slice(1).join('/')

    const options = {
      hostname: domain,
      path: `${path}?${smarturl_parameters}${md5HexDigest}`,
      method: 'GET'
    }

    const request = http.request(options, (response) => {
      let data = ''
      response.on('data', (chunk) => {
        data += chunk
      })

      response.on('end', () => {
        const parsedData = JSON.parse(data)
        res.status(200).json({
          success: true,
          result: parsedData,
          message: 'FETCHED_SUCCESSFULLY'
        })
      })
    })

    request.on('error', (error) => {
      res.status(400).json({
        success: false,
        result: error,
        message: 'CATALOGUE_NOT_FOUND'
      })
    })

    request.end()
  } catch (error) {
    handleError(res, error)
  }
}

module.exports = {
  getAllCategory,
  getAllMoviesFromCategory,
  getShemarooCatalog,
  getShemarooItems,
  getShemarooEpisodes,
  getVideoStream
}
