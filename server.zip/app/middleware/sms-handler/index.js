const { sendSMS } = require('./send_sms')

module.exports = {
  sendSMS
}
