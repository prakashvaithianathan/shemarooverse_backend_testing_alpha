const { usernameExists } = require('./usernameExists')

module.exports = {
  usernameExists
}
