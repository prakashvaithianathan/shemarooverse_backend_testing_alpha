const { checkOTP } = require('./check_otp')

module.exports = { checkOTP }
